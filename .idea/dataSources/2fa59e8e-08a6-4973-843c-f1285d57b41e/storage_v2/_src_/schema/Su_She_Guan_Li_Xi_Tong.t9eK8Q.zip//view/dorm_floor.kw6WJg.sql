create view dorm_floor as
select `宿舍管理系统`.`dorm`.`Dno`     AS `Dno`,
       `宿舍管理系统`.`floor`.`Fno`    AS `Fno`,
       `宿舍管理系统`.`floor`.`Fsex`   AS `Fsex`,
       `宿舍管理系统`.`dorm`.`Dnumber` AS `Dnumber`,
       `宿舍管理系统`.`dorm`.`DRB`     AS `DRB`,
       `宿舍管理系统`.`floor`.`DS`     AS `DS`
from `宿舍管理系统`.`floor`
         join `宿舍管理系统`.`dorm`
where (`宿舍管理系统`.`floor`.`Fno` = `宿舍管理系统`.`dorm`.`Fno`);

