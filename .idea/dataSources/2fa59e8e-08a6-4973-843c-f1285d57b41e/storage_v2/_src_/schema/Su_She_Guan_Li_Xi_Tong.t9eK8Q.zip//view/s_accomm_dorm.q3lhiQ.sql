create view s_accomm_dorm as
select `宿舍管理系统`.`student`.`Sno`       AS `sno`,
       `宿舍管理系统`.`student`.`Sname`     AS `sname`,
       `宿舍管理系统`.`student`.`Smajor`    AS `smajor`,
       `宿舍管理系统`.`dorm`.`Fno`          AS `fno`,
       `宿舍管理系统`.`dorm`.`Dno`          AS `dno`,
       `宿舍管理系统`.`accommodation`.`Bno` AS `bno`,
       `宿舍管理系统`.`dorm`.`DHname`       AS `DHname`
from `宿舍管理系统`.`student`
         join `宿舍管理系统`.`dorm`
         join `宿舍管理系统`.`accommodation`
where ((`宿舍管理系统`.`student`.`Sno` = `宿舍管理系统`.`accommodation`.`Sno`) and
       (`宿舍管理系统`.`accommodation`.`Dno` = `宿舍管理系统`.`dorm`.`Dno`));

