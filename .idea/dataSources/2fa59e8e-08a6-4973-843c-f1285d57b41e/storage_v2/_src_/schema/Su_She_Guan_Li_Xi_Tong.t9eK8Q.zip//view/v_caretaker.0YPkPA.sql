create view v_caretaker as
select `宿舍管理系统`.`caretaker`.`Cno`   AS `cno`,
       `宿舍管理系统`.`caretaker`.`Cname` AS `cname`,
       `宿舍管理系统`.`caretaker`.`Cage`  AS `cage`,
       `宿舍管理系统`.`caretaker`.`Csex`  AS `csex`,
       `宿舍管理系统`.`caretaker`.`Ctel`  AS `ctel`
from `宿舍管理系统`.`caretaker`;

