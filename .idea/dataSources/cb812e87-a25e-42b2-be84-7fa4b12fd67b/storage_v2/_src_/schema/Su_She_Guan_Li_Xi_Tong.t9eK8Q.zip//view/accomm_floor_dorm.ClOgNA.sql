create view accomm_floor_dorm as
select distinct `宿舍管理系统`.`dorm`.`Dno` AS `dno`, `宿舍管理系统`.`floor`.`Fno` AS `fno`, `宿舍管理系统`.`floor`.`DS` AS `ds`
from ((`宿舍管理系统`.`dorm` join `宿舍管理系统`.`floor`)
         join `宿舍管理系统`.`accommodation`)
where ((`宿舍管理系统`.`accommodation`.`Dno` = `宿舍管理系统`.`dorm`.`Dno`) and (`宿舍管理系统`.`dorm`.`Fno` = `宿舍管理系统`.`floor`.`Fno`));

