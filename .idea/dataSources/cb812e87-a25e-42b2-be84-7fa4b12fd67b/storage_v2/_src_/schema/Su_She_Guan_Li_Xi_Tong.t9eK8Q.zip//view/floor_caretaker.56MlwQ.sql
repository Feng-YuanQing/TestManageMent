create view floor_caretaker as
select `宿舍管理系统`.`floor`.`Fno`       AS `fno`,
       `宿舍管理系统`.`floor`.`Fsex`      AS `fsex`,
       `宿舍管理系统`.`floor`.`Cno`       AS `cno`,
       `宿舍管理系统`.`caretaker`.`Cname` AS `cname`,
       `宿舍管理系统`.`caretaker`.`Csex`  AS `csex`,
       `宿舍管理系统`.`floor`.`Fnumber`   AS `fnumber`,
       `宿舍管理系统`.`floor`.`DS`        AS `DS`
from (`宿舍管理系统`.`floor`
         join `宿舍管理系统`.`caretaker`)
where (`宿舍管理系统`.`floor`.`Cno` = `宿舍管理系统`.`caretaker`.`Cno`);

