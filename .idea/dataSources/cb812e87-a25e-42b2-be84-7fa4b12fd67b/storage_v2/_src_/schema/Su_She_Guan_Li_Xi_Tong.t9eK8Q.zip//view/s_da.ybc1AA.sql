create view s_da as
select `宿舍管理系统`.`dorm`.`Dno`       AS `Dno`,
       `宿舍管理系统`.`student`.`Sno`    AS `Sno`,
       `宿舍管理系统`.`student`.`Sname`  AS `Sname`,
       `宿舍管理系统`.`student`.`Sclass` AS `Sclass`,
       `宿舍管理系统`.`student`.`Smajor` AS `Smajor`,
       `宿舍管理系统`.`student`.`Stel`   AS `Stel`
from `宿舍管理系统`.`dorm`
         join `宿舍管理系统`.`student`
         join `宿舍管理系统`.`accommodation`
where ((`宿舍管理系统`.`accommodation`.`Sno` = `宿舍管理系统`.`student`.`Sno`) and
       (`宿舍管理系统`.`accommodation`.`Dno` = `宿舍管理系统`.`dorm`.`Dno`));

