create view v_s_info as
select `宿舍管理系统`.`student`.`Sno`         AS `Sno`,
       `宿舍管理系统`.`student`.`Sname`       AS `Sname`,
       `宿舍管理系统`.`student`.`Ssex`        AS `Ssex`,
       `宿舍管理系统`.`student`.`Stel`        AS `Stel`,
       `宿舍管理系统`.`student`.`Sclass`      AS `Sclass`,
       `宿舍管理系统`.`student`.`Sid`         AS `Sid`,
       `宿舍管理系统`.`student`.`Sage`        AS `Sage`,
       `宿舍管理系统`.`student`.`Smajor`      AS `Smajor`,
       `宿舍管理系统`.`student`.`Snative`     AS `Snative`,
       `宿舍管理系统`.`dorm`.`Dno`            AS `Dno`,
       `宿舍管理系统`.`floor`.`Fno`           AS `Fno`,
       `宿舍管理系统`.`caretaker`.`Cno`       AS `Cno`,
       `宿舍管理系统`.`accommodation`.`Bno`   AS `Bno`,
       `宿舍管理系统`.`accommodation`.`Atime` AS `Atime`,
       `宿舍管理系统`.`caretaker`.`Cname`     AS `Cname`,
       `宿舍管理系统`.`caretaker`.`Cage`      AS `Cage`,
       `宿舍管理系统`.`caretaker`.`Csex`      AS `Csex`,
       `宿舍管理系统`.`management`.`Mdate`    AS `Mdate`,
       `宿舍管理系统`.`management`.`Mmatter`  AS `Mmatter`,
       `宿舍管理系统`.`management`.`Mway`     AS `Mway`
from (((((`宿舍管理系统`.`student` join `宿舍管理系统`.`accommodation`) join `宿舍管理系统`.`floor`) join `宿舍管理系统`.`dorm`) join `宿舍管理系统`.`caretaker`)
         join `宿舍管理系统`.`management`)
where ((`宿舍管理系统`.`student`.`Sno` = `宿舍管理系统`.`accommodation`.`Sno`) and
       (`宿舍管理系统`.`floor`.`Fno` = `宿舍管理系统`.`dorm`.`Fno`) and (`宿舍管理系统`.`floor`.`Cno` = `宿舍管理系统`.`caretaker`.`Cno`) and
       (`宿舍管理系统`.`accommodation`.`Dno` = `宿舍管理系统`.`dorm`.`Dno`) and
       (`宿舍管理系统`.`management`.`Sno` = `宿舍管理系统`.`student`.`Sno`));

